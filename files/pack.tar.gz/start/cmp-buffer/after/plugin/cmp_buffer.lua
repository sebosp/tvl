require('cmp').register_source('buffer', require('cmp_buffer'))
