# cmp-vsnip

nvim-cmp source for [vim-vsnip](https://github.com/hrsh7th/vim-vsnip)

# Setup

```lua
require'cmp'.setup {
  sources = {
    { name = 'vsnip' }
  }
}
```

