require("tokyonight")._load("day")
